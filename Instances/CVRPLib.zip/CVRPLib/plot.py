import numpy as np
import matplotlib.pyplot as plt

fig, axes = plt.subplots(nrows=5, ncols=4, figsize=(8, 9))

sets = {'A': ['A-n32-k5', 'A-n33-k6', 'A-n33-k5', 'A-n34-k5'],
        'B': ['B-n31-k5', 'B-n34-k5', 'B-n35-k5', 'B-n38-k6'],
        'P': ['P-n20-k2', 'P-n50-k10', 'P-n60-k10', 'P-n76-k5'],
        'X': ['X-n101-k25', 'X-n200-k36', 'X-n480-k70', 'X-n979-k58'],
        'XML30': ['XML100_1116_13', 'XML100_2125_05', 'XML100_2275_04', 'XML100_3215_08']}

for row_idx, set_name in enumerate(sets.keys()):
    instances = sets[set_name]
    for col_idx, instance in enumerate(instances):
        path = f'{set_name}/{instance}.vrp'  # replace 'path_to_instances_folder' with your actual path
        file = open(path, "r")
        lines = [ll.strip() for ll in file]
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("DIMENSION"):
                dimension = int(line.split(':')[1])
            elif line.startswith("CAPACITY"):
                capacity = int(line.split(':')[1])
            elif line.startswith('NODE_COORD_SECTION'):
                locations = np.loadtxt(lines[i + 1:i + 1 + dimension], dtype=int)
                axes[row_idx, col_idx].scatter(locations[:, 1], locations[:, 2])
                #axes[row_idx, col_idx].set_xlabel('X Coordinate')
                #axes[row_idx, col_idx].set_ylabel('Y Coordinate')
                axes[row_idx, col_idx].set_title(instance)
                i = i + dimension
            elif line.startswith('DEMAND_SECTION'):
                demand = np.loadtxt(lines[i + 1:i + 1 + dimension], dtype=int)
                i = i + dimension
            i += 1
for ax in axes.flat:
    ax.set_xticks([]) 
    ax.set_yticks([])
plt.tight_layout()  # to improve the spacing between subplots
plt.savefig('plot.jpg')
plt.savefig('plot.pdf')
plt.show()

